package com.example.Medicalsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
